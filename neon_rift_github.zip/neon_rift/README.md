# Neon Rift: Survivor

A polished, dependency-free HTML5 survival game that runs entirely in the browser.

## Features

- Endless survival waves
- Boss fight every 5th wave
- 18 upgrade choices with build variety
- Smooth WASD / arrow movement
- Mouse aiming and hold-to-fire combat
- Dash mechanic with invulnerability burst
- XP / leveling / score system
- Energy shard pickups and magnet behavior
- Particle effects, glow, screen shake and animated background
- Best score saved locally with `localStorage`
- No backend, no database, no paid assets, no external libraries
- Works on GitHub Pages

## Controls

- **WASD / Arrow keys** — move
- **Mouse** — aim
- **Left click (hold)** — fire
- **Space** — dash

## Run locally

Just open `index.html` in a modern browser.

## Publish on GitHub Pages

1. Create a new GitHub repository.
2. Upload `index.html` and `README.md`.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select your main branch and the `/root` folder.
6. Save. GitHub will give you a public URL.

No build step is required.
